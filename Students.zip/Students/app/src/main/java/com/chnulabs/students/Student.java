package com.chnulabs.students;

import java.util.ArrayList;
import java.util.Arrays;


public class Student {
    private String name;
    private String groupNumber;

    public Student(String name, String groupNumber){
        this.name = name;
        this.groupNumber = groupNumber;
    }

    public String getName(){
        return name;
    }

    public String getGroupNumber(){
        return groupNumber;
    }

    private final static ArrayList<Student> students = new ArrayList<Student>(
            Arrays.asList(
                    new Student("Артем Захаров","301"),
                    new Student("Петро Яковенко","301"),
                    new Student("Іванов Роман","302"),
                    new Student("Петров Федір","302"),
                    new Student("Сергій Зорін","308"),
                    new Student("Назар Колісник","308"),
                    new Student("Олексій Симоненко","309"),
                    new Student("Антон Бондаренко","309")
            )
    );

    public static ArrayList<Student> getStudents(String groupNumber){
        ArrayList<Student> stList = new ArrayList<>();
        for (Student s: students){
            if (s.getGroupNumber().equals(groupNumber)){
                stList.add(s);
            }
        }
        return stList;
    }
    @Override
    public String toString(){
        return name;
    }
}
